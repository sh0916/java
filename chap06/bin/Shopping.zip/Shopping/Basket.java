package Shopping;

import java.util.ArrayList;

public class Basket {

	ArrayList userBasket = new ArrayList();
	
//	String getAddGoodsName() {
//		return this.goodsName;
//	}
	
//	void setAddGoodsName(String goodsName) {
//		if(goodsName != null) {
//			userBasket.add(goodsName);
//		}
//	}
	
}
